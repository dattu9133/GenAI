import ImageGenerator from "./components/ImageGen";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
      <ImageGenerator />
    </div>
  );
}

export default App;
